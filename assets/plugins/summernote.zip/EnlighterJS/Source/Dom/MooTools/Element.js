/*
---
description: EnlighterJS DOM Abstraction Layer (MooTools) - Just an Alias for MooTools Element

license: MIT-style X11 License

authors:
  - Andi Dittrich

requires:
  - Core/1.4.5

provides: [EnlighterJS.Dom.Element]
...
 */
EJS.Dom.Element = Element;