License
-------

EnlighterJS is OpenSource and licensed under the Terms of [The MIT License (X11)](http://opensource.org/licenses/MIT). You're welcome to [contribute](https://github.com/AndiDittrich/EnlighterJS/blob/master/CONTRIBUTE.md)!
