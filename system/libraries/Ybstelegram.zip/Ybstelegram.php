<?php

define("Connector","3696b14dc3ff4c4ad95ab0de4fb8d1c5");
define('cli','runscript');

include_once  "ybs/telegram/BotManager.php";

use ybs\telegram\BotManager;

class CI_Ybstelegram extends BotManager{
	
	public function __construct(){
		parent::__construct();
	}
	
	
	public function sendMessageToAdmin($message,$admin_bot){
		
		$field = array("sys_bot_telegram_register.*");
		$this->db->select($field);
		$this->db->where_in("sys_bot_telegram_admin_system.name",$admin_bot);
		$this->db->where("sys_bot_telegram_register.token <>",null);
		$this->db->join("sys_bot_telegram_register","sys_bot_telegram_register.id=sys_bot_telegram_admin_system.id_bot","LEFT");
		$admin = $this->db->get("sys_bot_telegram_admin_system")->result();
		
		foreach($admin as $v){
			$this->sendMessage($message,$v->token,$v->chat_id);
		}
		
	}
	
	


	
	
	
	
}