<?php
namespace ybs\telegram;



if (!defined('Connector'))
    exit('No direct script access allowed');



include_once BASEPATH . "libraries/ybs/cli/dbloader.php";
use ybs\cli\dbloader;

class Model extends dbloader{
	
	public function __construct(){
		parent::__construct();
	}

	
	
}	