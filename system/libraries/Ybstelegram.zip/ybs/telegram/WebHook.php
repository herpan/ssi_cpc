<?php
namespace ybs\telegram;
use ybs\telegram\BotManager;

include_once "BotManager.php";



class WebHook extends BotManager{

	public $request;
	public $request_Id;
	public $request_Message;
	
	public $bot;
	public $command;
	public $id;
	public $descriptions;
	public $name;
	public $key;
	
	public function __construct(){
		parent::__construct();
		
		$this->request =  file_get_contents("php://input");
		$this->request =  json_decode($this->request,TRUE);
		
		$this->request_Id 		= $this->request['message']['chat']['id']; 
		$this->request_Message 	= $this->request['message']['text'];
		
		$a = get_class($this);
		$this->getService($a);
		
		if($this->_TEST_CODE==true){
				$this->test();
		}else{
				$this->run();
		}
		
	}
	
	
	private function run(){

		if($this->command)
		foreach($this->command as $cmd ){
			$c = "/".$cmd['name'];
		
			if($c==$this->request_Message){
				$this->action($c,$cmd['message']);
				break;
			}
		}
	}
	
	
	private function getService($token){
			
			$this->db->where("sys_bot_telegram_service.key",$token);
			$data  = $this->db->get("sys_bot_telegram_service")->result_array();
			
			if($data){
					$this->id = $data[0]['id'];
					$this->name = $data[0]['name'];
					$this->key = $data[0]['key'];
					
					$this->command = $this->getCommand($this->id);
					$this->bot	   = $this->getBot($this->id);
					 
			}
		
			
			return $this;
	}
	
	
	private function getCommand($id_service){
		
			$this->db->where("sys_bot_telegram_service_cmd.id_service",$id_service);
			$data  = $this->db->get("sys_bot_telegram_service_cmd")->result_array();			
			return $data;
	}
	
	private function getBot($id_service){
										
			$this->db->join("sys_bot_telegram_register", "sys_bot_telegram_register.id=sys_bot_telegram_webhook.id_bot","LEFT");	
			$this->db->where("sys_bot_telegram_webhook.id_service",$id_service);								
			$data  = $this->db->get("sys_bot_telegram_webhook")->result_array();

			if($data){
				return $data[0]; 
			}								
			return NULL;
	}
	

	
	
	
	
	
	
	
	
	
	
}

